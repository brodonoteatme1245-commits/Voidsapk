package com.nexusvortex.explorer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.nexusvortex.explorer.ui.theme.NexusVortexExplorerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NexusVortexExplorerTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    // File browser + Spiral background here
    SpiralBackground()
    // Add LazyColumn for files, etc.
    // TODO: Full implementation per prompt
}

@Preview
@Composable
fun PreviewMain() {
    NexusVortexExplorerTheme {
        MainScreen()
    }
}