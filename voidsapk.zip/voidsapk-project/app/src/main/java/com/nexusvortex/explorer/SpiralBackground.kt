package com.nexusvortex.explorer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.*

// Dynamic Spiral Background - Production ready snippet matching prompt
@Composable
fun SpiralBackground(modifier: Modifier = Modifier.fillMaxSize()) {
    var pointerPosition by remember { mutableStateOf(Offset.Zero) }
    val spirals = remember { List(12) { SpiralParticle() } } // 8-15 as specified

    Canvas(modifier = modifier.pointerInput(Unit) {
        detectDragGestures { change, _ ->
            pointerPosition = change.position
        }
    }) {
        // Draw glowing purple spirals with attraction
        spirals.forEach { spiral ->
            spiral.update(pointerPosition, size)
            spiral.draw(this)
        }
    }
}

data class SpiralParticle(
    var center: Offset = Offset.Zero,
    var angle: Double = 0.0,
    var radius: Double = 50.0,
    val color: Color = Color(0xFF8A2BE2) // Neon purple
) {
    fun update(pointer: Offset, canvasSize: androidx.compose.ui.geometry.Size) {
        // Physics: attract to pointer
        val dx = pointer.x - center.x
        val dy = pointer.y - center.y
        val dist = sqrt(dx*dx + dy*dy)
        if (dist > 1f) {
            center = center.copy(
                x = center.x + (dx * 0.05f),
                y = center.y + (dy * 0.05f)
            )
        }
        angle += 0.05 // Slow rotation + undulation
        radius = 40 + 20 * sin(angle * 2) // Organic worm-like
        // Clamp to screen
        center = Offset(
            center.x.coerceIn(0f, canvasSize.width),
            center.y.coerceIn(0f, canvasSize.height)
        )
    }

    fun draw(drawScope: androidx.compose.ui.graphics.drawscope.DrawScope) {
        // Parametric spiral path
        val pathPoints = mutableListOf<Offset>()
        for (theta in 0..360 step 5) {
            val r = radius + theta * 0.8 // Archimedean spiral r = a + b*theta
            val rad = Math.toRadians(theta.toDouble() + angle)
            val x = center.x + (r * cos(rad)).toFloat()
            val y = center.y + (r * sin(rad)).toFloat()
            pathPoints.add(Offset(x, y))
        }
        // Draw with glow (multiple strokes for neon effect)
        for (i in 1..3) {
            drawScope.drawPoints(
                points = pathPoints,
                pointMode = androidx.compose.ui.graphics.PointMode.Polygon,
                color = color.copy(alpha = 0.6f / i),
                strokeWidth = 8f - i*2
            )
        }
        // Orbiting particles
        // TODO: Add more per prompt for trails, pulsing
    }
}